#|
$JSON
{"authURL":["ai2.appinventor.mit.edu"],"YaVersion":"233","Source":"Form","Properties":{"$Name":"Screen2","$Type":"Form","$Version":"31","ActionBar":"True","AppName":"bluetooth","ScreenOrientation":"landscape","Title":"Screen2","Uuid":"0"}}
|#